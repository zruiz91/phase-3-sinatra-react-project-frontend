import React from 'react';



function NavBar() {
    return (
        <div>
            <h1>NavBar</h1>
        </div>
    )
}

export default NavBar;